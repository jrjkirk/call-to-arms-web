<script lang="ts">
    import { onMount } from 'svelte';
    import { PUBLIC_API_URL } from '$env/static/public';
    import {
        NONE_FACTION,
        TOW_FACTIONS, HH_FACTIONS, KT_FACTIONS,
        ETA_OPTIONS,
        EXPERIENCE_OPTIONS,
    } from '$lib/signupOptions';

    const VALID_SCOPES = ['The Old World', 'The Horus Heresy', 'Kill Team', 'League'];
    const SYSTEM_SCOPES = ['The Old World', 'The Horus Heresy', 'Kill Team'];

    type AdminMe = { is_super_admin: boolean; scopes: string[] };
    type RoleEntry = { user_id: number; discord_name: string; player_name: string | null; scope: string };
    type SuperAdminEntry = { user_id: number; discord_name: string; player_name: string | null };
    type RolesData = { roles: RoleEntry[]; super_admins: SuperAdminEntry[] };
    type GrantableUser = { id: number; discord_name: string; player_name: string };
    type BlockEntry = {
        block_id: number;
        player_a_id: number;
        player_a_name: string;
        player_b_id: number;
        player_b_name: string;
        note: string | null;
    };
    type BlockPlayer = { id: number; name: string };
    type DisplayRow = {
        id: number | null;
        a_signup_id: number;
        a_name: string;
        a_faction: string | null;
        a_vibe: string | null;
        b_signup_id: number | null;
        b_name: string | null;
        b_faction: string | null;
        b_vibe: string | null;
        type: string | null;
        eta: string | null;
        points: string | null;
        prearranged: boolean;
    };
    type SignupItem = { id: number; name: string; faction: string | null; vibe: string | null };
    type AdminSignupRow = {
        id: number;
        player_id: number;
        player_name: string;
        faction: string | null;
        points: number | null | undefined;
        eta: string | null;
        experience: string | null;
        vibe: string | null;
        standby_ok: boolean;
        scenario: string | null;
        can_demo: boolean;
    };
    type SignupConfig = {
        show_points: boolean;
        default_points: number | null;
        show_scenario: boolean;
        show_standby: boolean;
        show_can_demo: boolean;
        vibe_options: string[];
        vibe_fixed: string | null;
    };
    type AddSignupForm = {
        open: boolean;
        playerId: string;
        faction: string;
        points: number | null | undefined;
        eta: string;
        experience: string;
        vibe: string;
        standbyOk: boolean;
        scenario: string;
        canDemo: boolean;
        submitting: boolean;
        error: string | null;
    };
    type LeagueResultRow = {
        id: number;
        result_date: string;
        player_1_id: number;
        player_1_name: string;
        player_1_faction: string | null;
        player_1_painting_bonus: string | null;
        player_1_rating_before: number;
        player_1_rating_after: number;
        player_2_id: number;
        player_2_name: string;
        player_2_faction: string | null;
        player_2_painting_bonus: string | null;
        player_2_rating_before: number;
        player_2_rating_after: number;
        game_type: string;
        result: string;
        k_factor_used: number;
    };
    type PairingsState = {
        week: string;
        rows: DisplayRow[];
        editRows: EditRow[];
        published: boolean;
        signups: SignupItem[];
        loading: boolean;
        saving: boolean;
        posting: boolean;
        dirty: boolean;
        error: string | null;
        message: string | null;
        signupRows: AdminSignupRow[];
        signupConfig: SignupConfig | null;
        signupsLoading: boolean;
        signupsError: string | null;
        addSignup: AddSignupForm;
    };
    type EditRow = {
        id: number | null;
        a_signup_id: number | null;
        b_signup_id: number | null;
        a_faction: string;
        b_faction: string;
        a_type: string;
        b_type: string;
        type: string;
        eta: string;
        points: string;
        prearranged: boolean;
    };

    let adminMe = $state<AdminMe | null>(null);
    let rolesData = $state<RolesData | null>(null);
    let grantableUsers = $state<GrantableUser[]>([]);
    let pageLoading = $state(true);
    let rolesLoading = $state(false);

    let blocks = $state<BlockEntry[]>([]);
    let blocksLoading = $state(false);
    let blockPlayers = $state<BlockPlayer[]>([]);
    let historyByScope = $state<Record<string, any[]>>({});
    let leagueResults = $state<LeagueResultRow[]>([]);
    let leagueResultsLoading = $state(false);
    let leagueResultsError = $state<string | null>(null);

    const PAINTING_OPTIONS = ['Partially Painted', 'Fully Painted'];
    const GAME_TYPE_OPTIONS = ['Casual', 'Competitive'];
    let historyLoading = $state<Record<string, boolean>>({});

    // Per-scope pairings state
    let pairings = $state<Record<string, PairingsState>>({});

    // Appoint form state
    let grantUserIdStr = $state('');
    let grantScope = $state(VALID_SCOPES[0]);
    let granting = $state(false);
    let grantError = $state<string | null>(null);

    // Add block form state
    let addBlockP1Str = $state('');
    let addBlockP2Str = $state('');
    let addBlockNote = $state('');
    let addingBlock = $state(false);
    let addBlockError = $state<string | null>(null);

    function defaultWeekFor(system: string): string {
        const target = system === 'The Old World' ? 3 : 5;
        const d = new Date();
        const day = d.getDay();
        const daysAhead = (target - day + 7) % 7;
        d.setDate(d.getDate() + (daysAhead === 0 ? 7 : daysAhead));
        const dd = String(d.getDate()).padStart(2, '0');
        const mm = String(d.getMonth() + 1).padStart(2, '0');
        const yyyy = d.getFullYear();
        return `${dd}/${mm}/${yyyy}`;
    }

    function factionsFor(system: string): string[] {
        if (system === 'The Horus Heresy') return HH_FACTIONS;
        if (system === 'Kill Team') return KT_FACTIONS;
        return TOW_FACTIONS;
    }

    function vibeOptionsFor(system: string): string[] {
        if (system === 'Kill Team') return ['Standard'];
        if (system === 'The Horus Heresy') return ['Standard', 'Intro'];
        return ['Casual', 'Competitive', 'Intro', 'Either'];
    }

    function showPoints(system: string): boolean {
        return system !== 'Kill Team';
    }

    function displayRowToEdit(r: DisplayRow): EditRow {
        return {
            id: r.id,
            a_signup_id: r.a_signup_id,
            b_signup_id: r.b_signup_id,
            a_faction: r.a_faction ?? NONE_FACTION,
            b_faction: r.b_faction ?? NONE_FACTION,
            a_type: r.a_vibe ?? '',
            b_type: r.b_vibe ?? '',
            type: r.type ?? '',
            eta: r.eta ?? '',
            points: r.points ?? '',
            prearranged: r.prearranged,
        };
    }

    function defaultAddSignupForm(): AddSignupForm {
        return {
            open: false,
            playerId: '',
            faction: NONE_FACTION,
            points: null,
            eta: '',
            experience: 'New',
            vibe: '',
            standbyOk: false,
            scenario: '',
            canDemo: false,
            submitting: false,
            error: null,
        };
    }

    function initPairingsState(scope: string): PairingsState {
        return {
            week: defaultWeekFor(scope),
            rows: [],
            editRows: [],
            published: false,
            signups: [],
            loading: false,
            saving: false,
            posting: false,
            dirty: false,
            error: null,
            message: null,
            signupRows: [],
            signupConfig: null,
            signupsLoading: false,
            signupsError: null,
            addSignup: defaultAddSignupForm(),
        };
    }

    async function loadPairings(scope: string) {
        const ps = pairings[scope];
        if (!ps) return;
        ps.loading = true;
        ps.error = null;
        ps.message = null;
        const params = new URLSearchParams({ system: scope, week: ps.week });
        const r = await fetch(`${PUBLIC_API_URL}/admin/pairings?${params}`, { credentials: 'include' });
        if (r.ok) {
            const data = await r.json();
            ps.rows = data.rows ?? [];
            ps.editRows = ps.rows.map(displayRowToEdit);
            ps.published = data.published ?? false;
            ps.dirty = false;
        } else {
            ps.error = 'Failed to load pairings.';
        }
        await loadSignups(scope);
        await loadAdminSignups(scope);
        ps.loading = false;
    }

    async function loadSignups(scope: string) {
        const ps = pairings[scope];
        if (!ps) return;
        const params = new URLSearchParams({ system: scope, week: ps.week });
        const r = await fetch(`${PUBLIC_API_URL}/admin/pairings/signup-list?${params}`, { credentials: 'include' });
        if (r.ok) ps.signups = await r.json();
    }

    async function loadAdminSignups(scope: string) {
        const ps = pairings[scope];
        if (!ps) return;
        ps.signupsLoading = true;
        ps.signupsError = null;
        const params = new URLSearchParams({ system: scope, week: ps.week });
        const r = await fetch(`${PUBLIC_API_URL}/admin/signups?${params}`, { credentials: 'include' });
        if (r.ok) {
            const data = await r.json();
            const config: SignupConfig = data.config;
            ps.signupConfig = config;
            ps.signupRows = (data.signups ?? []).map((su: AdminSignupRow) => ({
                ...su,
                faction: su.faction ?? NONE_FACTION,
                eta: su.eta ?? '',
                vibe: su.vibe ?? config.vibe_fixed ?? config.vibe_options[0] ?? '',
                scenario: su.scenario ?? '',
            }));
            ps.addSignup.points = config.default_points;
            ps.addSignup.vibe = config.vibe_fixed ?? config.vibe_options[0] ?? '';
        } else {
            ps.signupsError = 'Failed to load signups.';
        }
        ps.signupsLoading = false;
    }

    async function patchSignup(scope: string, su: AdminSignupRow, field: keyof AdminSignupRow, value: any) {
        const ps = pairings[scope];
        if (!ps) return;
        let v = value;
        if (typeof v === 'number' && isNaN(v)) v = null;
        if (v === undefined) v = null;
        if (field === 'scenario' && v === '') v = null;
        if (field === 'eta' && v === '') v = null;
        const r = await fetch(`${PUBLIC_API_URL}/admin/signups/${su.id}`, {
            method: 'PATCH',
            credentials: 'include',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ [field]: v }),
        });
        if (r.ok) {
            const updated = await r.json();
            su.faction = updated.faction ?? NONE_FACTION;
            su.points = updated.points;
            su.eta = updated.eta ?? '';
            su.experience = updated.experience;
            su.vibe = updated.vibe ?? '';
            su.standby_ok = updated.standby_ok;
            su.scenario = updated.scenario ?? '';
            su.can_demo = updated.can_demo;
        } else {
            const body = await r.json().catch(() => ({}));
            ps.signupsError = body.detail || 'Failed to update signup.';
        }
    }

    async function forceDropSignup(scope: string, signupId: number) {
        const ps = pairings[scope];
        if (!ps) return;
        if (!confirm('Force drop this signup? This cannot be undone.')) return;
        const r = await fetch(`${PUBLIC_API_URL}/admin/signups/${signupId}`, {
            method: 'DELETE',
            credentials: 'include',
        });
        if (r.ok) {
            ps.signupRows = ps.signupRows.filter((su) => su.id !== signupId);
        } else {
            const body = await r.json().catch(() => ({}));
            ps.signupsError = body.detail || 'Failed to drop signup.';
        }
    }

    async function submitAddSignup(scope: string) {
        const ps = pairings[scope];
        if (!ps) return;
        const form = ps.addSignup;
        if (!form.playerId) {
            form.error = 'Select a player.';
            return;
        }
        form.submitting = true;
        form.error = null;
        const body: Record<string, any> = {
            system: scope,
            week: ps.week,
            player_id: Number(form.playerId),
            faction: form.faction === NONE_FACTION ? null : form.faction,
            eta: form.eta || null,
            experience: form.experience,
            standby_ok: form.standbyOk,
            can_demo: form.canDemo,
        };
        if (ps.signupConfig?.show_points) body.points = form.points;
        if (!ps.signupConfig?.vibe_fixed) body.vibe = form.vibe;
        if (ps.signupConfig?.show_scenario) body.scenario = form.scenario || null;

        const r = await fetch(`${PUBLIC_API_URL}/admin/signups`, {
            method: 'POST',
            credentials: 'include',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(body),
        });
        if (r.ok) {
            const created: AdminSignupRow = await r.json();
            ps.signupRows = [
                ...ps.signupRows,
                {
                    ...created,
                    faction: created.faction ?? NONE_FACTION,
                    eta: created.eta ?? '',
                    vibe: created.vibe ?? '',
                    scenario: created.scenario ?? '',
                },
            ].sort((a, b) => a.player_name.localeCompare(b.player_name));
            ps.addSignup = defaultAddSignupForm();
            ps.addSignup.points = ps.signupConfig?.default_points ?? null;
            ps.addSignup.vibe = ps.signupConfig?.vibe_fixed ?? ps.signupConfig?.vibe_options[0] ?? '';
        } else {
            const body2 = await r.json().catch(() => ({}));
            form.error = body2.detail || 'Failed to add signup.';
        }
        form.submitting = false;
    }

    async function generatePairings(scope: string) {
        const ps = pairings[scope];
        if (!ps) return;
        ps.loading = true;
        ps.error = null;
        ps.message = null;
        const r = await fetch(`${PUBLIC_API_URL}/admin/pairings/generate`, {
            method: 'POST',
            credentials: 'include',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ system: scope, week: ps.week }),
        });
        if (r.ok) {
            const data = await r.json();
            ps.rows = data.rows ?? [];
            ps.editRows = ps.rows.map(displayRowToEdit);
            ps.dirty = false;
            ps.message = `Generated ${ps.rows.length} pairing(s).`;
        } else {
            const body = await r.json().catch(() => ({}));
            ps.error = body.detail || 'Generation failed.';
        }
        ps.loading = false;
    }

    async function savePairings(scope: string) {
        const ps = pairings[scope];
        if (!ps) return;
        ps.saving = true;
        ps.error = null;
        ps.message = null;
        const rows = ps.editRows.filter(r => r.id !== null);
        const r = await fetch(`${PUBLIC_API_URL}/admin/pairings/save`, {
            method: 'POST',
            credentials: 'include',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ system: scope, week: ps.week, rows }),
        });
        if (r.ok) {
            const data = await r.json();
            ps.dirty = false;
            ps.message = `Saved ${data.changed} pairing(s).`;
            await loadPairings(scope);
        } else {
            const body = await r.json().catch(() => ({}));
            ps.error = body.detail || 'Save failed.';
        }
        ps.saving = false;
    }

    async function togglePublish(scope: string) {
        const ps = pairings[scope];
        if (!ps) return;
        const newPublished = !ps.published;
        ps.error = null;
        ps.message = null;
        const r = await fetch(`${PUBLIC_API_URL}/admin/pairings/publish`, {
            method: 'POST',
            credentials: 'include',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ system: scope, week: ps.week, published: newPublished }),
        });
        if (r.ok) {
            ps.published = newPublished;
            ps.message = newPublished ? 'Pairings published.' : 'Pairings unpublished.';
        } else {
            const body = await r.json().catch(() => ({}));
            ps.error = body.detail || 'Publish toggle failed.';
        }
    }

    async function postDiscord(scope: string) {
        const ps = pairings[scope];
        if (!ps) return;
        ps.posting = true;
        ps.error = null;
        ps.message = null;
        const r = await fetch(`${PUBLIC_API_URL}/admin/pairings/post-discord`, {
            method: 'POST',
            credentials: 'include',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ system: scope, week: ps.week }),
        });
        if (r.ok) {
            const data = await r.json();
            ps.message = data.posted ? 'Posted to Discord.' : `Not posted: ${data.reason}.`;
        } else {
            const body = await r.json().catch(() => ({}));
            ps.error = body.detail || 'Discord post failed.';
        }
        ps.posting = false;
    }

    async function deletePairing(scope: string, rowId: number) {
        const ps = pairings[scope];
        if (!ps) return;
        ps.error = null;
        ps.message = null;
        const r = await fetch(`${PUBLIC_API_URL}/admin/pairings`, {
            method: 'DELETE',
            credentials: 'include',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ system: scope, week: ps.week, ids: [rowId] }),
        });
        if (r.ok) {
            await loadPairings(scope);
        } else {
            const body = await r.json().catch(() => ({}));
            ps.error = body.detail || 'Delete failed.';
        }
    }

    async function loadAdminMe() {
        const r = await fetch(`${PUBLIC_API_URL}/admin/me`, { credentials: 'include' });
        adminMe = r.ok ? await r.json() : null;
    }

    async function loadRoles() {
        rolesLoading = true;
        const r = await fetch(`${PUBLIC_API_URL}/admin/roles`, { credentials: 'include' });
        if (r.ok) rolesData = await r.json();
        rolesLoading = false;
    }

    async function loadGrantableUsers() {
        const r = await fetch(`${PUBLIC_API_URL}/admin/grantable-users`, { credentials: 'include' });
        if (r.ok) grantableUsers = await r.json();
    }

    async function loadBlocks() {
        blocksLoading = true;
        const r = await fetch(`${PUBLIC_API_URL}/admin/blocks`, { credentials: 'include' });
        if (r.ok) blocks = await r.json();
        blocksLoading = false;
    }

    async function loadBlockPlayers() {
        const r = await fetch(`${PUBLIC_API_URL}/admin/blocks/players`, { credentials: 'include' });
        if (r.ok) blockPlayers = await r.json();
    }

    async function loadLeagueResults() {
        leagueResultsLoading = true;
        leagueResultsError = null;
        const r = await fetch(`${PUBLIC_API_URL}/admin/league/results`, { credentials: 'include' });
        if (r.ok) {
            const data: LeagueResultRow[] = await r.json();
            leagueResults = data.map((row) => ({
                ...row,
                player_1_faction: row.player_1_faction ?? '',
                player_2_faction: row.player_2_faction ?? '',
                player_1_painting_bonus: row.player_1_painting_bonus ?? NONE_FACTION,
                player_2_painting_bonus: row.player_2_painting_bonus ?? NONE_FACTION,
            }));
        } else {
            leagueResultsError = 'Failed to load league results.';
        }
        leagueResultsLoading = false;
    }

    async function patchLeagueResult(resultId: number, field: string, rawValue: any) {
        leagueResultsError = null;
        let v: any = rawValue;
        if (field === 'player_1_id' || field === 'player_2_id') {
            v = Number(v);
        } else if (field === 'player_1_faction' || field === 'player_2_faction') {
            v = v === '' ? null : v;
        } else if (field === 'player_1_painting_bonus' || field === 'player_2_painting_bonus') {
            v = v === NONE_FACTION ? null : v;
        }
        const r = await fetch(`${PUBLIC_API_URL}/admin/league/results/${resultId}`, {
            method: 'PATCH',
            credentials: 'include',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ [field]: v }),
        });
        if (r.ok) {
            await loadLeagueResults();
        } else {
            const body = await r.json().catch(() => ({}));
            leagueResultsError = body.detail || 'Failed to update result.';
        }
    }

    async function deleteLeagueResult(resultId: number) {
        if (!confirm('Delete this result? This recalculates ELO ratings for all players.')) return;
        leagueResultsError = null;
        const r = await fetch(`${PUBLIC_API_URL}/admin/league/results/${resultId}`, {
            method: 'DELETE',
            credentials: 'include',
        });
        if (r.ok) {
            await loadLeagueResults();
        } else {
            const body = await r.json().catch(() => ({}));
            leagueResultsError = body.detail || 'Failed to delete result.';
        }
    }

    async function loadHistory(scope: string) {
        historyLoading[scope] = true;
        const r = await fetch(
            `${PUBLIC_API_URL}/admin/history?scope=${encodeURIComponent(scope)}`,
            { credentials: 'include' }
        );
        if (r.ok) historyByScope[scope] = await r.json();
        historyLoading[scope] = false;
    }

    onMount(async () => {
        await loadAdminMe();
        if (!adminMe || (!adminMe.is_super_admin && adminMe.scopes.length === 0)) {
            pageLoading = false;
            return;
        }
        const tasks: Promise<void>[] = [loadBlocks()];
        if (adminMe.is_super_admin) {
            tasks.push(loadRoles(), loadGrantableUsers());
        }
        if (adminMe.is_super_admin || adminMe.scopes.includes('League')) {
            tasks.push(loadBlockPlayers());
        }
        for (const scope of adminMe.scopes) {
            if (scope === 'League') {
                tasks.push(loadLeagueResults());
            } else {
                tasks.push(loadHistory(scope));
            }
            if (SYSTEM_SCOPES.includes(scope)) {
                pairings[scope] = initPairingsState(scope);
                tasks.push(loadPairings(scope));
            }
        }
        await Promise.all(tasks);
        pageLoading = false;
    });

    const rolesByUser = $derived.by(() => {
        if (!rolesData) return [];
        const map = new Map<number, { discord_name: string; player_name: string | null; scopes: string[] }>();
        for (const role of rolesData.roles) {
            if (!map.has(role.user_id)) {
                map.set(role.user_id, { discord_name: role.discord_name, player_name: role.player_name, scopes: [] });
            }
            map.get(role.user_id)!.scopes.push(role.scope);
        }
        return [...map.entries()].map(([user_id, v]) => ({ user_id, ...v }));
    });

    async function removeRole(userId: number, scope: string) {
        const params = new URLSearchParams({ user_id: String(userId), scope });
        const r = await fetch(`${PUBLIC_API_URL}/admin/roles?${params}`, {
            method: 'DELETE',
            credentials: 'include',
        });
        if (r.ok) await loadRoles();
    }

    async function grantRole() {
        if (!grantUserIdStr) return;
        granting = true;
        grantError = null;
        const r = await fetch(`${PUBLIC_API_URL}/admin/roles`, {
            method: 'POST',
            credentials: 'include',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ user_id: Number(grantUserIdStr), scope: grantScope }),
        });
        if (!r.ok) {
            const body = await r.json().catch(() => ({}));
            grantError = body.detail || 'Failed to grant role.';
        } else {
            grantUserIdStr = '';
            await loadRoles();
        }
        granting = false;
    }

    async function addBlock() {
        if (!addBlockP1Str || !addBlockP2Str || addBlockP1Str === addBlockP2Str) return;
        addingBlock = true;
        addBlockError = null;
        const r = await fetch(`${PUBLIC_API_URL}/admin/blocks`, {
            method: 'POST',
            credentials: 'include',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                player_a_id: Number(addBlockP1Str),
                player_b_id: Number(addBlockP2Str),
                note: addBlockNote.trim() || null,
            }),
        });
        if (!r.ok) {
            const body = await r.json().catch(() => ({}));
            addBlockError = body.detail || 'Failed to add block.';
        } else {
            addBlockP1Str = '';
            addBlockP2Str = '';
            addBlockNote = '';
            await loadBlocks();
        }
        addingBlock = false;
    }

    async function removeBlock(playerAId: number, playerBId: number) {
        const params = new URLSearchParams({
            player_a_id: String(playerAId),
            player_b_id: String(playerBId),
        });
        const r = await fetch(`${PUBLIC_API_URL}/admin/blocks?${params}`, {
            method: 'DELETE',
            credentials: 'include',
        });
        if (r.ok) await loadBlocks();
    }

    function displayName(entry: { discord_name: string; player_name: string | null }): string {
        return entry.player_name ? `${entry.player_name} (${entry.discord_name})` : entry.discord_name;
    }

    function fmt(f: string | null | undefined): string {
        return f || '—';
    }
</script>

<h2 class="page-heading">Admin</h2>

{#if pageLoading}
    <p class="muted">Loading…</p>
{:else if !adminMe || (!adminMe.is_super_admin && adminMe.scopes.length === 0)}
    <p class="muted">You don't have admin access.</p>
{:else}

    {#if adminMe.is_super_admin}
        <!-- ── Manage Admins ───────────────────────────────────────────────── -->
        <section class="admin-section">
            <h3 class="section-heading">Manage Admins</h3>

            <div class="sub-section">
                <h4 class="sub-heading">Super-admins <span class="badge">managed via SQL</span></h4>
                {#if rolesData && rolesData.super_admins.length > 0}
                    <ul class="name-list">
                        {#each rolesData.super_admins as sa}
                            <li>{displayName(sa)}</li>
                        {/each}
                    </ul>
                {:else if rolesData}
                    <p class="muted">None.</p>
                {:else}
                    <p class="muted">…</p>
                {/if}
            </div>

            <div class="sub-section">
                <h4 class="sub-heading">Scope roles</h4>
                {#if rolesLoading}
                    <p class="muted">Loading…</p>
                {:else if rolesByUser.length === 0}
                    <p class="muted">No scope admins yet.</p>
                {:else}
                    <div class="roles-table">
                        {#each rolesByUser as person}
                            <div class="roles-row">
                                <div class="roles-person">{displayName(person)}</div>
                                <div class="roles-scopes">
                                    {#each person.scopes as scope}
                                        <span class="scope-chip">
                                            {scope}
                                            <button
                                                class="remove-btn"
                                                type="button"
                                                title="Remove {scope} from {person.discord_name}"
                                                onclick={() => removeRole(person.user_id, scope)}
                                            >×</button>
                                        </span>
                                    {/each}
                                </div>
                            </div>
                        {/each}
                    </div>
                {/if}
            </div>

            <div class="sub-section">
                <h4 class="sub-heading">Appoint admin</h4>
                <form class="appoint-form" onsubmit={(e) => { e.preventDefault(); grantRole(); }}>
                    <div class="field">
                        <label class="field-label" for="grant-user">User</label>
                        <select id="grant-user" class="field-select" bind:value={grantUserIdStr}>
                            <option value="">— Select user —</option>
                            {#each grantableUsers as u}
                                <option value={String(u.id)}>{u.player_name} ({u.discord_name})</option>
                            {/each}
                        </select>
                    </div>
                    <div class="field">
                        <label class="field-label" for="grant-scope">Scope</label>
                        <select id="grant-scope" class="field-select" bind:value={grantScope}>
                            {#each VALID_SCOPES as s}
                                <option>{s}</option>
                            {/each}
                        </select>
                    </div>
                    {#if grantError}
                        <p class="field-error">{grantError}</p>
                    {/if}
                    <button
                        type="submit"
                        class="primary-button"
                        disabled={!grantUserIdStr || granting}
                    >
                        {granting ? 'Appointing…' : 'Appoint'}
                    </button>
                </form>
            </div>
        </section>
    {/if}

    <!-- ── Pairing Blocks ─────────────────────────────────────────────── -->
    <section class="admin-section">
        <h3 class="section-heading">Pairing Blocks</h3>
        <p class="section-intro">Blocks prevent two players from being paired. They apply across all systems.</p>

        {#if adminMe.is_super_admin}
            <div class="sub-section">
                <h4 class="sub-heading">Add block</h4>
                <form class="appoint-form" onsubmit={(e) => { e.preventDefault(); addBlock(); }}>
                    <div class="field">
                        <label class="field-label" for="block-p1">Player A</label>
                        <select id="block-p1" class="field-select" bind:value={addBlockP1Str}>
                            <option value="">— Select —</option>
                            {#each blockPlayers as p}
                                <option value={String(p.id)}>{p.name}</option>
                            {/each}
                        </select>
                    </div>
                    <div class="field">
                        <label class="field-label" for="block-p2">Player B</label>
                        <select id="block-p2" class="field-select" bind:value={addBlockP2Str}>
                            <option value="">— Select —</option>
                            {#each blockPlayers as p}
                                <option value={String(p.id)}>{p.name}</option>
                            {/each}
                        </select>
                    </div>
                    <div class="field">
                        <label class="field-label" for="block-note">Note</label>
                        <input
                            id="block-note"
                            class="field-input"
                            type="text"
                            bind:value={addBlockNote}
                            placeholder="optional reason…"
                        />
                    </div>
                    {#if addBlockP1Str && addBlockP2Str && addBlockP1Str === addBlockP2Str}
                        <p class="field-error">Players must be different.</p>
                    {/if}
                    {#if addBlockError}
                        <p class="field-error">{addBlockError}</p>
                    {/if}
                    <button
                        type="submit"
                        class="primary-button"
                        disabled={!addBlockP1Str || !addBlockP2Str || addBlockP1Str === addBlockP2Str || addingBlock}
                    >
                        {addingBlock ? 'Adding…' : 'Add Block'}
                    </button>
                </form>
            </div>
        {/if}

        <div class="sub-section">
            {#if blocksLoading}
                <p class="muted">Loading…</p>
            {:else if blocks.length === 0}
                <p class="muted">No blocks configured.</p>
            {:else}
                <ul class="block-list">
                    {#each blocks as block}
                        <li class="block-row">
                            <span class="block-names">
                                <strong>{block.player_a_name}</strong>
                                <span class="block-x">✕</span>
                                <strong>{block.player_b_name}</strong>
                            </span>
                            {#if block.note}
                                <span class="block-note">{block.note}</span>
                            {/if}
                            {#if adminMe.is_super_admin}
                                <button
                                    class="remove-btn block-remove"
                                    type="button"
                                    title="Remove block"
                                    onclick={() => removeBlock(block.player_a_id, block.player_b_id)}
                                >×</button>
                            {/if}
                        </li>
                    {/each}
                </ul>
            {/if}
        </div>

        {#if !adminMe.is_super_admin}
            <p class="muted small">Block list is managed by the lead admin.</p>
        {/if}
    </section>

    <!-- ── Per-scope cards ───────────────────────────────────────────── -->
    {#if adminMe.scopes.length > 0}
        <section class="admin-section">
            <h3 class="section-heading">Your Scopes</h3>
            <div class="scope-cards">
                {#each adminMe.scopes as scope}
                    <div class="scope-card">
                        <div class="scope-card-title">{scope}</div>

                        {#if scope === 'League'}
                            <!-- League Results (read-write — editing/deleting recalculates ELO) -->
                            <div class="sub-section">
                                <h4 class="sub-heading">League Results</h4>

                                {#if leagueResultsError}
                                    <p class="field-error">{leagueResultsError}</p>
                                {/if}

                                {#if leagueResultsLoading}
                                    <p class="muted small">Loading…</p>
                                {:else if leagueResults.length === 0}
                                    <p class="muted small">No results recorded yet.</p>
                                {:else}
                                    <div class="grid-wrap league-results-wrap">
                                        <table class="pairing-grid league-results-grid">
                                            <thead>
                                                <tr>
                                                    <th>Date</th>
                                                    <th>Player 1</th>
                                                    <th>P1 Faction</th>
                                                    <th>P1 Painting</th>
                                                    <th>P1 Before</th>
                                                    <th>P1 After</th>
                                                    <th>Result</th>
                                                    <th>Type</th>
                                                    <th>Player 2</th>
                                                    <th>P2 Faction</th>
                                                    <th>P2 Painting</th>
                                                    <th>P2 Before</th>
                                                    <th>P2 After</th>
                                                    <th></th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                {#each leagueResults as r (r.id)}
                                                    <tr>
                                                        <td><span class="cell-text">{r.result_date}</span></td>
                                                        <td>
                                                            <select
                                                                class="cell-select"
                                                                value={String(r.player_1_id)}
                                                                onchange={(e) => patchLeagueResult(r.id, 'player_1_id', (e.target as HTMLSelectElement).value)}
                                                            >
                                                                {#each blockPlayers as p}
                                                                    <option value={String(p.id)}>{p.name}</option>
                                                                {/each}
                                                            </select>
                                                        </td>
                                                        <td>
                                                            <input
                                                                class="cell-input"
                                                                type="text"
                                                                bind:value={r.player_1_faction}
                                                                onchange={() => patchLeagueResult(r.id, 'player_1_faction', r.player_1_faction)}
                                                            />
                                                        </td>
                                                        <td>
                                                            <select
                                                                class="cell-select"
                                                                bind:value={r.player_1_painting_bonus}
                                                                onchange={() => patchLeagueResult(r.id, 'player_1_painting_bonus', r.player_1_painting_bonus)}
                                                            >
                                                                <option value={NONE_FACTION}>{NONE_FACTION}</option>
                                                                {#each PAINTING_OPTIONS as opt}
                                                                    <option>{opt}</option>
                                                                {/each}
                                                            </select>
                                                        </td>
                                                        <td><span class="cell-readonly">{Math.round(r.player_1_rating_before)}</span></td>
                                                        <td><span class="cell-readonly">{Math.round(r.player_1_rating_after)}</span></td>
                                                        <td>
                                                            <select
                                                                class="cell-select"
                                                                bind:value={r.result}
                                                                onchange={() => patchLeagueResult(r.id, 'result', r.result)}
                                                            >
                                                                <option value="Player 1 Victory">{r.player_1_name} Victory</option>
                                                                <option value="Draw">Draw</option>
                                                                <option value="Player 2 Victory">{r.player_2_name} Victory</option>
                                                            </select>
                                                        </td>
                                                        <td>
                                                            <select
                                                                class="cell-select"
                                                                bind:value={r.game_type}
                                                                onchange={() => patchLeagueResult(r.id, 'game_type', r.game_type)}
                                                            >
                                                                {#each GAME_TYPE_OPTIONS as opt}
                                                                    <option>{opt}</option>
                                                                {/each}
                                                            </select>
                                                        </td>
                                                        <td>
                                                            <select
                                                                class="cell-select"
                                                                value={String(r.player_2_id)}
                                                                onchange={(e) => patchLeagueResult(r.id, 'player_2_id', (e.target as HTMLSelectElement).value)}
                                                            >
                                                                {#each blockPlayers as p}
                                                                    <option value={String(p.id)}>{p.name}</option>
                                                                {/each}
                                                            </select>
                                                        </td>
                                                        <td>
                                                            <input
                                                                class="cell-input"
                                                                type="text"
                                                                bind:value={r.player_2_faction}
                                                                onchange={() => patchLeagueResult(r.id, 'player_2_faction', r.player_2_faction)}
                                                            />
                                                        </td>
                                                        <td>
                                                            <select
                                                                class="cell-select"
                                                                bind:value={r.player_2_painting_bonus}
                                                                onchange={() => patchLeagueResult(r.id, 'player_2_painting_bonus', r.player_2_painting_bonus)}
                                                            >
                                                                <option value={NONE_FACTION}>{NONE_FACTION}</option>
                                                                {#each PAINTING_OPTIONS as opt}
                                                                    <option>{opt}</option>
                                                                {/each}
                                                            </select>
                                                        </td>
                                                        <td><span class="cell-readonly">{Math.round(r.player_2_rating_before)}</span></td>
                                                        <td><span class="cell-readonly">{Math.round(r.player_2_rating_after)}</span></td>
                                                        <td class="cell-delete">
                                                            <button
                                                                class="remove-btn"
                                                                type="button"
                                                                title="Delete this result"
                                                                onclick={() => deleteLeagueResult(r.id)}
                                                            >×</button>
                                                        </td>
                                                    </tr>
                                                {/each}
                                            </tbody>
                                        </table>
                                    </div>
                                {/if}
                            </div>
                        {:else}
                            <!-- Recent Games -->
                            <div class="sub-section">
                                <h4 class="sub-heading">Recent Games</h4>
                                {#if historyLoading[scope]}
                                    <p class="muted small">Loading…</p>
                                {:else if !(historyByScope[scope]?.length)}
                                    <p class="muted small">No games recorded yet.</p>
                                {:else}
                                    <ul class="history-list">
                                        {#each historyByScope[scope] as entry}
                                            <li class="history-row">
                                                <span class="history-date">{entry.week}</span>
                                                {#if entry.player_b_name}
                                                    <span class="history-matchup">
                                                        {entry.player_a_name} ({fmt(entry.player_a_faction)}) vs {entry.player_b_name} ({fmt(entry.player_b_faction)})
                                                    </span>
                                                {:else}
                                                    <span class="history-matchup">
                                                        {entry.player_a_name} ({fmt(entry.player_a_faction)}) — bye
                                                    </span>
                                                {/if}
                                            </li>
                                        {/each}
                                    </ul>
                                {/if}
                            </div>
                        {/if}

                        <!-- Weekly Pairings (system scopes only) -->
                        {#if SYSTEM_SCOPES.includes(scope) && pairings[scope]}
                            {@const ps = pairings[scope]}

                            <!-- This Week's Signups -->
                            <div class="sub-section">
                                <h4 class="sub-heading">This Week's Signups</h4>

                                {#if ps.signupsError}
                                    <p class="field-error">{ps.signupsError}</p>
                                {/if}

                                {#if ps.signupsLoading}
                                    <p class="muted small">Loading…</p>
                                {:else if ps.signupRows.length === 0}
                                    <p class="muted small">No signups for this week yet.</p>
                                {:else}
                                    <div class="grid-wrap">
                                        <table class="pairing-grid">
                                            <thead>
                                                <tr>
                                                    <th>Name</th>
                                                    <th>Faction</th>
                                                    {#if ps.signupConfig?.show_points}<th>Pts</th>{/if}
                                                    <th>ETA</th>
                                                    <th>Exp</th>
                                                    <th>Vibe</th>
                                                    {#if ps.signupConfig?.show_standby}<th>Standby</th>{/if}
                                                    {#if ps.signupConfig?.show_scenario}<th>Scenario</th>{/if}
                                                    {#if ps.signupConfig?.show_can_demo}<th>Demo</th>{/if}
                                                    <th></th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                {#each ps.signupRows as su (su.id)}
                                                    <tr>
                                                        <td><span class="cell-text">{su.player_name}</span></td>
                                                        <td>
                                                            <select
                                                                class="cell-select"
                                                                bind:value={su.faction}
                                                                onchange={() => patchSignup(scope, su, 'faction', su.faction)}
                                                            >
                                                                <option value={NONE_FACTION}>{NONE_FACTION}</option>
                                                                {#each factionsFor(scope) as f}
                                                                    <option>{f}</option>
                                                                {/each}
                                                            </select>
                                                        </td>
                                                        {#if ps.signupConfig?.show_points}
                                                            <td>
                                                                <input
                                                                    class="cell-input-num"
                                                                    type="number"
                                                                    min="0"
                                                                    max="10000"
                                                                    step="250"
                                                                    bind:value={su.points}
                                                                    onchange={() => patchSignup(scope, su, 'points', su.points)}
                                                                />
                                                            </td>
                                                        {/if}
                                                        <td>
                                                            <select
                                                                class="cell-select"
                                                                bind:value={su.eta}
                                                                onchange={() => patchSignup(scope, su, 'eta', su.eta)}
                                                            >
                                                                <option value="">—</option>
                                                                {#each ETA_OPTIONS as t}
                                                                    <option>{t}</option>
                                                                {/each}
                                                            </select>
                                                        </td>
                                                        <td>
                                                            <select
                                                                class="cell-select"
                                                                bind:value={su.experience}
                                                                onchange={() => patchSignup(scope, su, 'experience', su.experience)}
                                                            >
                                                                {#each EXPERIENCE_OPTIONS as e}
                                                                    <option>{e}</option>
                                                                {/each}
                                                            </select>
                                                        </td>
                                                        <td>
                                                            {#if ps.signupConfig?.vibe_fixed}
                                                                <span class="cell-text">{ps.signupConfig.vibe_fixed}</span>
                                                            {:else}
                                                                <select
                                                                    class="cell-select"
                                                                    bind:value={su.vibe}
                                                                    onchange={() => patchSignup(scope, su, 'vibe', su.vibe)}
                                                                >
                                                                    {#each ps.signupConfig?.vibe_options ?? [] as v}
                                                                        <option>{v}</option>
                                                                    {/each}
                                                                </select>
                                                            {/if}
                                                        </td>
                                                        {#if ps.signupConfig?.show_standby}
                                                            <td class="cell-check">
                                                                <input
                                                                    type="checkbox"
                                                                    bind:checked={su.standby_ok}
                                                                    onchange={() => patchSignup(scope, su, 'standby_ok', su.standby_ok)}
                                                                />
                                                            </td>
                                                        {/if}
                                                        {#if ps.signupConfig?.show_scenario}
                                                            <td>
                                                                <input
                                                                    class="cell-input"
                                                                    type="text"
                                                                    bind:value={su.scenario}
                                                                    onchange={() => patchSignup(scope, su, 'scenario', su.scenario)}
                                                                />
                                                            </td>
                                                        {/if}
                                                        {#if ps.signupConfig?.show_can_demo}
                                                            <td class="cell-check">
                                                                <input
                                                                    type="checkbox"
                                                                    bind:checked={su.can_demo}
                                                                    onchange={() => patchSignup(scope, su, 'can_demo', su.can_demo)}
                                                                />
                                                            </td>
                                                        {/if}
                                                        <td class="cell-delete">
                                                            <button
                                                                class="remove-btn"
                                                                type="button"
                                                                title="Force drop this signup"
                                                                onclick={() => forceDropSignup(scope, su.id)}
                                                            >×</button>
                                                        </td>
                                                    </tr>
                                                {/each}
                                            </tbody>
                                        </table>
                                    </div>
                                {/if}

                                <details class="add-signup-details" bind:open={ps.addSignup.open}>
                                    <summary>+ Add signup</summary>
                                    <div class="add-signup-form">
                                        <div class="field">
                                            <label class="field-label" for="add-player-{scope}">Player</label>
                                            <select id="add-player-{scope}" class="field-select" bind:value={ps.addSignup.playerId}>
                                                <option value="">— Select —</option>
                                                {#each blockPlayers as p}
                                                    <option value={String(p.id)}>{p.name}</option>
                                                {/each}
                                            </select>
                                        </div>
                                        <div class="field">
                                            <label class="field-label" for="add-faction-{scope}">Faction</label>
                                            <select id="add-faction-{scope}" class="field-select" bind:value={ps.addSignup.faction}>
                                                <option value={NONE_FACTION}>{NONE_FACTION}</option>
                                                {#each factionsFor(scope) as f}
                                                    <option>{f}</option>
                                                {/each}
                                            </select>
                                        </div>
                                        {#if ps.signupConfig?.show_points}
                                            <div class="field">
                                                <label class="field-label" for="add-points-{scope}">Points</label>
                                                <input id="add-points-{scope}" class="field-input" type="number" min="0" max="10000" step="250" bind:value={ps.addSignup.points} />
                                            </div>
                                        {/if}
                                        <div class="field">
                                            <label class="field-label" for="add-eta-{scope}">ETA</label>
                                            <select id="add-eta-{scope}" class="field-select" bind:value={ps.addSignup.eta}>
                                                <option value="">—</option>
                                                {#each ETA_OPTIONS as t}
                                                    <option>{t}</option>
                                                {/each}
                                            </select>
                                        </div>
                                        <div class="field">
                                            <label class="field-label" for="add-exp-{scope}">Experience</label>
                                            <select id="add-exp-{scope}" class="field-select" bind:value={ps.addSignup.experience}>
                                                {#each EXPERIENCE_OPTIONS as e}
                                                    <option>{e}</option>
                                                {/each}
                                            </select>
                                        </div>
                                        {#if !ps.signupConfig?.vibe_fixed}
                                            <div class="field">
                                                <label class="field-label" for="add-vibe-{scope}">Vibe</label>
                                                <select id="add-vibe-{scope}" class="field-select" bind:value={ps.addSignup.vibe}>
                                                    {#each ps.signupConfig?.vibe_options ?? [] as v}
                                                        <option>{v}</option>
                                                    {/each}
                                                </select>
                                            </div>
                                        {/if}
                                        {#if ps.signupConfig?.show_standby}
                                            <label class="check-row">
                                                <input type="checkbox" bind:checked={ps.addSignup.standbyOk} />
                                                <span>Standby</span>
                                            </label>
                                        {/if}
                                        {#if ps.signupConfig?.show_scenario}
                                            <div class="field">
                                                <label class="field-label" for="add-scenario-{scope}">Scenario</label>
                                                <input id="add-scenario-{scope}" class="field-input" type="text" bind:value={ps.addSignup.scenario} />
                                            </div>
                                        {/if}
                                        {#if ps.signupConfig?.show_can_demo}
                                            <label class="check-row">
                                                <input type="checkbox" bind:checked={ps.addSignup.canDemo} />
                                                <span>Can demo</span>
                                            </label>
                                        {/if}
                                    </div>
                                    {#if ps.addSignup.error}
                                        <p class="field-error">{ps.addSignup.error}</p>
                                    {/if}
                                    <button
                                        class="primary-button"
                                        type="button"
                                        disabled={ps.addSignup.submitting}
                                        onclick={() => submitAddSignup(scope)}
                                    >{ps.addSignup.submitting ? 'Adding…' : 'Add signup'}</button>
                                </details>
                            </div>

                            <div class="sub-section pairings-section">
                                <h4 class="sub-heading">
                                    Weekly Pairings
                                    {#if ps.published}
                                        <span class="pub-badge pub-live">● Published</span>
                                    {:else}
                                        <span class="pub-badge pub-draft">○ Unpublished</span>
                                    {/if}
                                </h4>

                                <!-- Week input + action buttons -->
                                <div class="pairing-controls">
                                    <div class="field field-narrow">
                                        <label class="field-label" for="week-{scope}">Week</label>
                                        <input
                                            id="week-{scope}"
                                            class="field-input week-input"
                                            type="text"
                                            placeholder="DD/MM/YYYY"
                                            bind:value={ps.week}
                                            onblur={() => loadPairings(scope)}
                                        />
                                    </div>
                                    <div class="pairing-btn-row">
                                        <button
                                            class="primary-button"
                                            type="button"
                                            disabled={ps.loading}
                                            onclick={() => generatePairings(scope)}
                                        >{ps.loading ? 'Working…' : 'Generate'}</button>
                                        <button
                                            class={`publish-btn ${ps.published ? 'pub-on' : 'pub-off'}`}
                                            type="button"
                                            onclick={() => togglePublish(scope)}
                                        >{ps.published ? 'Unpublish' : 'Publish'}</button>
                                        <button
                                            class="secondary-button"
                                            type="button"
                                            disabled={ps.posting}
                                            onclick={() => postDiscord(scope)}
                                        >{ps.posting ? 'Posting…' : 'Post to Discord'}</button>
                                    </div>
                                </div>

                                {#if ps.error}
                                    <p class="field-error">{ps.error}</p>
                                {/if}
                                {#if ps.message}
                                    <p class="pairing-message">{ps.message}</p>
                                {/if}

                                {#if ps.editRows.length === 0 && !ps.loading}
                                    <p class="muted small">No pairings for this week. Generate to create them.</p>
                                {:else if ps.editRows.length > 0}
                                    <!-- Editable grid -->
                                    <div class="grid-wrap">
                                        <table class="pairing-grid">
                                            <thead>
                                                <tr>
                                                    <th>A</th>
                                                    <th>A Faction</th>
                                                    <th>A Type</th>
                                                    <th>B</th>
                                                    <th>B Faction</th>
                                                    <th>B Type</th>
                                                    <th>Type</th>
                                                    {#if showPoints(scope)}<th>ETA</th><th>Pts</th>{/if}
                                                    <th></th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                {#each ps.editRows as er, idx}
                                                    <tr class:prearranged-row={er.prearranged}>
                                                        <!-- A signup -->
                                                        <td>
                                                            {#if er.id === null}
                                                                <span class="cell-text">{ps.rows[idx]?.a_name ?? '—'}</span>
                                                            {:else}
                                                                <select
                                                                    class="cell-select"
                                                                    value={String(er.a_signup_id ?? '')}
                                                                    onchange={(e) => {
                                                                        const v = (e.target as HTMLSelectElement).value;
                                                                        er.a_signup_id = v ? Number(v) : null;
                                                                        ps.dirty = true;
                                                                    }}
                                                                >
                                                                    {#each ps.signups as su}
                                                                        <option value={String(su.id)}>{su.id} — {su.name}</option>
                                                                    {/each}
                                                                </select>
                                                            {/if}
                                                        </td>
                                                        <!-- A Faction -->
                                                        <td>
                                                            {#if er.id === null}
                                                                <span class="cell-text">{er.a_faction || '—'}</span>
                                                            {:else}
                                                                <select
                                                                    class="cell-select"
                                                                    bind:value={er.a_faction}
                                                                    onchange={() => (ps.dirty = true)}
                                                                >
                                                                    <option value={NONE_FACTION}>{NONE_FACTION}</option>
                                                                    {#each factionsFor(scope) as f}
                                                                        <option>{f}</option>
                                                                    {/each}
                                                                </select>
                                                            {/if}
                                                        </td>
                                                        <!-- A Type -->
                                                        <td>
                                                            {#if er.id === null}
                                                                <span class="cell-text">{er.a_type || '—'}</span>
                                                            {:else}
                                                                <select
                                                                    class="cell-select"
                                                                    bind:value={er.a_type}
                                                                    onchange={() => (ps.dirty = true)}
                                                                >
                                                                    <option value="">—</option>
                                                                    {#each vibeOptionsFor(scope) as v}
                                                                        <option>{v}</option>
                                                                    {/each}
                                                                </select>
                                                            {/if}
                                                        </td>
                                                        <!-- B signup -->
                                                        <td>
                                                            {#if er.id === null}
                                                                <span class="cell-text">{ps.rows[idx]?.b_name ?? 'BYE'}</span>
                                                            {:else}
                                                                <select
                                                                    class="cell-select"
                                                                    value={String(er.b_signup_id ?? '')}
                                                                    onchange={(e) => {
                                                                        const v = (e.target as HTMLSelectElement).value;
                                                                        er.b_signup_id = v ? Number(v) : null;
                                                                        ps.dirty = true;
                                                                    }}
                                                                >
                                                                    <option value="">BYE</option>
                                                                    {#each ps.signups as su}
                                                                        <option value={String(su.id)}>{su.id} — {su.name}</option>
                                                                    {/each}
                                                                </select>
                                                            {/if}
                                                        </td>
                                                        <!-- B Faction -->
                                                        <td>
                                                            {#if er.id === null}
                                                                <span class="cell-text">{er.b_faction || '—'}</span>
                                                            {:else}
                                                                <select
                                                                    class="cell-select"
                                                                    bind:value={er.b_faction}
                                                                    onchange={() => (ps.dirty = true)}
                                                                >
                                                                    <option value={NONE_FACTION}>{NONE_FACTION}</option>
                                                                    {#each factionsFor(scope) as f}
                                                                        <option>{f}</option>
                                                                    {/each}
                                                                </select>
                                                            {/if}
                                                        </td>
                                                        <!-- B Type -->
                                                        <td>
                                                            {#if er.id === null}
                                                                <span class="cell-text">{er.b_type || '—'}</span>
                                                            {:else}
                                                                <select
                                                                    class="cell-select"
                                                                    bind:value={er.b_type}
                                                                    onchange={() => (ps.dirty = true)}
                                                                >
                                                                    <option value="">—</option>
                                                                    {#each vibeOptionsFor(scope) as v}
                                                                        <option>{v}</option>
                                                                    {/each}
                                                                </select>
                                                            {/if}
                                                        </td>
                                                        <!-- Shared Type -->
                                                        <td>
                                                            {#if er.id === null}
                                                                <span class="cell-text">{er.type || '—'}</span>
                                                            {:else}
                                                                <select
                                                                    class="cell-select"
                                                                    bind:value={er.type}
                                                                    onchange={() => (ps.dirty = true)}
                                                                >
                                                                    <option value="">—</option>
                                                                    {#each vibeOptionsFor(scope) as v}
                                                                        <option>{v}</option>
                                                                    {/each}
                                                                </select>
                                                            {/if}
                                                        </td>
                                                        <!-- ETA + Points (points-bearing systems) -->
                                                        {#if showPoints(scope)}
                                                            <td>
                                                                {#if er.id === null}
                                                                    <span class="cell-text">{er.eta || '—'}</span>
                                                                {:else}
                                                                    <select
                                                                        class="cell-select"
                                                                        bind:value={er.eta}
                                                                        onchange={() => (ps.dirty = true)}
                                                                    >
                                                                        <option value="">—</option>
                                                                        {#each ETA_OPTIONS as t}
                                                                            <option>{t}</option>
                                                                        {/each}
                                                                    </select>
                                                                {/if}
                                                            </td>
                                                            <td>
                                                                {#if er.id === null}
                                                                    <span class="cell-text">{er.points || '—'}</span>
                                                                {:else}
                                                                    <input
                                                                        class="cell-input-num"
                                                                        type="number"
                                                                        min="0"
                                                                        step="250"
                                                                        bind:value={er.points}
                                                                        oninput={() => (ps.dirty = true)}
                                                                    />
                                                                {/if}
                                                            </td>
                                                        {/if}
                                                        <!-- Delete -->
                                                        <td class="cell-delete">
                                                            {#if er.id !== null}
                                                                <button
                                                                    class="remove-btn"
                                                                    type="button"
                                                                    title="Delete this pairing"
                                                                    onclick={() => deletePairing(scope, er.id!)}
                                                                >×</button>
                                                            {/if}
                                                        </td>
                                                    </tr>
                                                {/each}
                                            </tbody>
                                        </table>
                                    </div>

                                    <div class="save-row">
                                        {#if ps.dirty}
                                            <span class="dirty-indicator">Unsaved changes</span>
                                        {/if}
                                        <button
                                            class="primary-button"
                                            type="button"
                                            disabled={ps.saving || !ps.dirty}
                                            onclick={() => savePairings(scope)}
                                        >{ps.saving ? 'Saving…' : 'Save Pairing Changes'}</button>
                                    </div>
                                {/if}
                            </div>
                        {/if}

                    </div>
                {/each}
            </div>
        </section>
    {/if}

{/if}

<style>
    .page-heading {
        font-size: 1.5rem;
        margin: 0 0 1.5rem;
    }

    .muted {
        color: var(--color-text-muted);
        font-style: italic;
    }

    .small {
        font-size: 0.82rem;
    }

    .admin-section {
        margin-bottom: 2rem;
    }

    .section-heading {
        font-size: 1.1rem;
        font-weight: 700;
        color: var(--color-accent);
        text-transform: uppercase;
        letter-spacing: 0.06em;
        margin: 0 0 0.75rem;
        padding-bottom: 0.4rem;
        border-bottom: 1px solid var(--color-accent-border);
    }

    .section-intro {
        font-size: 0.85rem;
        color: var(--color-text-muted);
        margin: 0 0 1rem;
    }

    .sub-section {
        margin-bottom: 1.5rem;
    }

    .sub-heading {
        font-size: 0.8rem;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.6px;
        color: var(--color-text-muted);
        margin: 0 0 0.6rem;
        display: flex;
        align-items: center;
        gap: 0.5rem;
    }

    .badge {
        font-size: 0.7rem;
        font-weight: 400;
        text-transform: none;
        letter-spacing: 0;
        background: rgba(148, 163, 184, 0.1);
        border: 1px solid rgba(148, 163, 184, 0.25);
        color: var(--color-text-faint);
        padding: 1px 6px;
        border-radius: 4px;
    }

    .name-list {
        list-style: none;
        padding: 0;
        margin: 0;
        display: flex;
        flex-direction: column;
        gap: 0.3rem;
    }

    .name-list li {
        font-size: 0.9rem;
        color: var(--color-text-base);
        padding: 4px 8px;
        background: rgba(0, 0, 0, 0.15);
        border-radius: 6px;
        border: 1px solid var(--color-accent-border-soft);
        display: inline-block;
        width: fit-content;
    }

    .roles-table {
        display: flex;
        flex-direction: column;
        gap: 0.5rem;
    }

    .roles-row {
        display: flex;
        align-items: center;
        gap: 0.75rem;
        padding: 8px 10px;
        background: rgba(0, 0, 0, 0.15);
        border: 1px solid var(--color-accent-border-soft);
        border-radius: 8px;
        flex-wrap: wrap;
    }

    .roles-person {
        font-size: 0.9rem;
        font-weight: 600;
        color: var(--color-text-bright);
        min-width: 160px;
    }

    .roles-scopes {
        display: flex;
        flex-wrap: wrap;
        gap: 0.4rem;
    }

    .scope-chip {
        display: inline-flex;
        align-items: center;
        gap: 0.3rem;
        background: rgba(201, 161, 74, 0.12);
        border: 1px solid rgba(201, 161, 74, 0.35);
        color: var(--color-accent);
        font-size: 0.78rem;
        font-weight: 600;
        padding: 2px 8px 2px 10px;
        border-radius: 999px;
    }

    .remove-btn {
        background: none;
        border: none;
        color: var(--color-text-muted);
        cursor: pointer;
        font-size: 1rem;
        line-height: 1;
        padding: 0;
        transition: color 0.15s;
    }

    .remove-btn:hover {
        color: #f87171;
    }

    /* ── Blocks ────────────────────────────────────────────────────────── */

    .block-list {
        list-style: none;
        padding: 0;
        margin: 0;
        display: flex;
        flex-direction: column;
        gap: 0.35rem;
    }

    .block-row {
        display: flex;
        align-items: center;
        gap: 0.6rem;
        padding: 5px 10px;
        background: rgba(0, 0, 0, 0.15);
        border: 1px solid var(--color-accent-border-soft);
        border-radius: 7px;
        font-size: 0.88rem;
        flex-wrap: wrap;
    }

    .block-names {
        display: flex;
        align-items: center;
        gap: 0.4rem;
        flex: 1;
        min-width: 0;
    }

    .block-x {
        color: var(--color-text-muted);
        font-size: 0.78rem;
    }

    .block-note {
        font-size: 0.78rem;
        color: var(--color-text-dim);
        font-style: italic;
    }

    .block-remove {
        margin-left: auto;
        flex: 0 0 auto;
    }

    /* ── Forms ─────────────────────────────────────────────────────────── */

    .appoint-form {
        display: flex;
        flex-wrap: wrap;
        align-items: flex-end;
        gap: 0.75rem;
    }

    .field {
        display: flex;
        flex-direction: column;
        gap: 0.3rem;
        min-width: 160px;
    }

    .field-narrow {
        min-width: 130px;
        max-width: 160px;
    }

    .field-label {
        font-size: 0.72rem;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.6px;
        color: var(--color-accent);
    }

    .field-select {
        background: var(--color-surface-dark);
        border: 1px solid var(--color-accent-border);
        border-radius: 6px;
        color: var(--color-text-base);
        padding: 7px 10px;
        font-size: 0.9rem;
        cursor: pointer;
    }

    .field-select:focus {
        outline: none;
        border-color: var(--color-accent);
    }

    .field-input {
        background: var(--color-surface-dark);
        border: 1px solid var(--color-accent-border);
        border-radius: 6px;
        color: var(--color-text-base);
        padding: 7px 10px;
        font-size: 0.9rem;
        font-family: inherit;
    }

    .field-input::placeholder {
        color: var(--color-text-faint);
    }

    .field-input:focus {
        outline: none;
        border-color: var(--color-accent);
    }

    .field-error {
        font-size: 0.8rem;
        color: #f87171;
        margin: 0.25rem 0 0;
        width: 100%;
    }

    .primary-button {
        background: var(--color-accent);
        color: #111;
        border: none;
        border-radius: 8px;
        padding: 0 14px;
        height: 2.2rem;
        box-sizing: border-box;
        font-size: 0.85rem;
        font-weight: 700;
        cursor: pointer;
        transition: opacity 0.15s;
        white-space: nowrap;
    }

    .primary-button:disabled {
        opacity: 0.45;
        cursor: not-allowed;
    }

    .primary-button:not(:disabled):hover {
        opacity: 0.85;
    }

    .secondary-button {
        background: transparent;
        color: var(--color-accent);
        border: 1px solid var(--color-accent-border);
        border-radius: 8px;
        padding: 0 14px;
        height: 2.2rem;
        box-sizing: border-box;
        font-size: 0.85rem;
        font-weight: 600;
        cursor: pointer;
        transition: background 0.15s;
        white-space: nowrap;
    }

    .secondary-button:disabled {
        opacity: 0.45;
        cursor: not-allowed;
    }

    .secondary-button:not(:disabled):hover {
        background: rgba(201, 161, 74, 0.1);
    }

    .publish-btn {
        border: none;
        border-radius: 8px;
        padding: 0 14px;
        height: 2.2rem;
        box-sizing: border-box;
        font-size: 0.85rem;
        font-weight: 700;
        cursor: pointer;
        transition: opacity 0.15s;
        white-space: nowrap;
    }

    .pub-on {
        background: #7f1d1d;
        color: #fca5a5;
    }

    .pub-off {
        background: #166534;
        color: #bbf7d0;
    }

    .publish-btn:hover {
        opacity: 0.85;
    }

    /* ── Scope cards ────────────────────────────────────────────────────── */

    .scope-cards {
        display: flex;
        flex-direction: column;
        gap: 1.5rem;
    }

    .scope-card {
        background: var(--color-sidebar-bg);
        border: 1px solid var(--color-accent-border);
        border-radius: 12px;
        padding: 1.2rem 1.4rem;
        box-shadow: 0 4px 14px rgba(0, 0, 0, 0.25);
    }

    .scope-card-title {
        font-size: 0.9rem;
        font-weight: 700;
        color: var(--color-accent);
        text-transform: uppercase;
        letter-spacing: 0.05em;
        margin-bottom: 1rem;
    }

    /* ── History list ───────────────────────────────────────────────────── */

    .history-list {
        list-style: none;
        padding: 0;
        margin: 0;
        display: flex;
        flex-direction: column;
        gap: 0;
        max-height: 320px;
        overflow-y: auto;
    }

    .history-row {
        display: flex;
        align-items: baseline;
        gap: 0.6rem;
        padding: 4px 6px;
        font-size: 0.82rem;
        color: var(--color-text-base);
        flex-wrap: wrap;
        border-radius: 4px;
    }

    .history-row:nth-child(odd) {
        background: rgba(0, 0, 0, 0.12);
    }

    .history-date {
        font-size: 0.74rem;
        color: var(--color-text-muted);
        white-space: nowrap;
        flex: 0 0 auto;
        min-width: 5.5rem;
        font-variant-numeric: tabular-nums;
    }

    .history-matchup {
        flex: 1;
        min-width: 0;
    }

    .history-result {
        font-size: 0.76rem;
        color: var(--color-text-dim);
        white-space: nowrap;
        flex: 0 0 auto;
    }

    /* ── Pairings section ───────────────────────────────────────────────── */

    .pairings-section {
        border-top: 1px solid var(--color-accent-border-soft);
        padding-top: 1rem;
        margin-top: 1rem;
    }

    .pub-badge {
        font-size: 0.7rem;
        font-weight: 600;
        text-transform: none;
        letter-spacing: 0;
        padding: 2px 8px;
        border-radius: 999px;
    }

    .pub-live {
        background: rgba(22, 101, 52, 0.4);
        color: #86efac;
        border: 1px solid #166534;
    }

    .pub-draft {
        background: rgba(127, 29, 29, 0.3);
        color: #fca5a5;
        border: 1px solid #7f1d1d;
    }

    .pairing-controls {
        display: flex;
        flex-direction: column;
        align-items: flex-start;
        gap: 0.6rem;
        margin-bottom: 0.75rem;
    }

    /* Force the same explicit height as the action buttons — <input> and
       <button> have different intrinsic height behaviour even with identical
       padding/font/border, so matching those properties alone isn't enough. */
    .week-input {
        padding: 0 14px;
        height: 2.2rem;
        box-sizing: border-box;
        font-size: 0.85rem;
    }

    .pairing-btn-row {
        display: flex;
        flex-wrap: wrap;
        gap: 0.5rem;
        align-items: center;
    }

    .preview-row td {
        opacity: 0.75;
    }

    .pairing-message {
        font-size: 0.8rem;
        color: #86efac;
        margin: 0 0 0.5rem;
    }

    /* ── Pairing grid ───────────────────────────────────────────────────── */

    .grid-wrap {
        overflow-x: auto;
        margin-bottom: 0.75rem;
    }

    .pairing-grid {
        width: 100%;
        border-collapse: collapse;
        font-size: 0.78rem;
        min-width: 700px;
    }

    .pairing-grid th {
        text-align: left;
        padding: 5px 6px;
        font-size: 0.68rem;
        font-weight: 700;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        color: var(--color-text-muted);
        border-bottom: 1px solid var(--color-accent-border-soft);
        white-space: nowrap;
    }

    .pairing-grid td {
        padding: 4px 4px;
        border-bottom: 1px solid rgba(255, 255, 255, 0.04);
        vertical-align: middle;
    }

    .pairing-grid tr:hover td {
        background: rgba(255, 255, 255, 0.02);
    }

    .prearranged-row td {
        background: rgba(201, 161, 74, 0.06);
    }

    .preview-row td {
        opacity: 0.75;
    }

    .cell-select {
        background: var(--color-surface-dark);
        border: 1px solid var(--color-accent-border-soft);
        border-radius: 4px;
        color: var(--color-text-base);
        padding: 3px 6px;
        font-size: 0.75rem;
        width: 100%;
        max-width: 160px;
        cursor: pointer;
    }

    .cell-select:focus {
        outline: none;
        border-color: var(--color-accent);
    }

    .cell-input-num {
        background: var(--color-surface-dark);
        border: 1px solid var(--color-accent-border-soft);
        border-radius: 4px;
        color: var(--color-text-base);
        padding: 3px 6px;
        font-size: 0.75rem;
        width: 72px;
        font-family: inherit;
    }

    .cell-input-num:focus {
        outline: none;
        border-color: var(--color-accent);
    }

    .cell-text {
        font-size: 0.78rem;
        color: var(--color-text-base);
    }

    .cell-readonly {
        font-size: 0.78rem;
        color: var(--color-text-muted);
        font-variant-numeric: tabular-nums;
    }

    .league-results-grid {
        min-width: 1300px;
    }

    .league-results-wrap {
        max-height: 320px;
        overflow-y: auto;
    }

    .league-results-grid thead th {
        position: sticky;
        top: 0;
        z-index: 1;
        background: var(--color-sidebar-bg);
    }

    .cell-delete {
        width: 28px;
        text-align: center;
    }

    .cell-check {
        width: 50px;
        text-align: center;
    }

    .cell-input {
        background: var(--color-surface-dark);
        border: 1px solid var(--color-accent-border-soft);
        border-radius: 4px;
        color: var(--color-text-base);
        padding: 3px 6px;
        font-size: 0.75rem;
        width: 100%;
        max-width: 140px;
        font-family: inherit;
    }

    .cell-input:focus {
        outline: none;
        border-color: var(--color-accent);
    }

    .add-signup-details {
        margin-top: 0.5rem;
    }

    .add-signup-details summary {
        cursor: pointer;
        font-weight: 600;
        color: var(--color-accent);
        font-size: 0.85rem;
        list-style: none;
    }

    .add-signup-details summary::-webkit-details-marker { display: none; }

    .add-signup-form {
        display: flex;
        flex-wrap: wrap;
        gap: 0.75rem;
        margin: 0.75rem 0;
    }

    .add-signup-form .field {
        min-width: 140px;
    }

    .check-row {
        display: flex;
        align-items: center;
        gap: 0.4rem;
        font-size: 0.85rem;
        color: var(--color-text-base);
    }

    .save-row {
        display: flex;
        align-items: center;
        gap: 1rem;
        margin-top: 0.5rem;
    }

    .dirty-indicator {
        font-size: 0.78rem;
        color: #fbbf24;
        font-style: italic;
    }
</style>
