<script lang="ts">
    import '../app.css';
    import { onMount } from 'svelte';
    import { page } from '$app/state';
    import { navigating } from '$app/stores';
    import { PUBLIC_API_URL } from '$env/static/public';
    import { fly } from 'svelte/transition';

    let { children } = $props();

    type AuthState = {
        authenticated: boolean;
        user?: { id: number; discord_name: string; avatar_url: string | null; player_id: number | null };
        player?: { id: number; name: string } | null;
        claim_candidates?: Array<{ id: number; name: string; default_faction: string | null }>;
    };

    type AdminState = {
        is_super_admin: boolean;
        scopes: string[];
    };

    let auth = $state<AuthState>({ authenticated: false });
    let adminState = $state<AdminState | null>(null);
    let authLoaded = $state(false);
    let drawerOpen = $state(false);

    async function refreshAuth() {
        try {
            const [authResp, adminResp] = await Promise.all([
                fetch(`${PUBLIC_API_URL}/auth/me`, { credentials: 'include' }),
                fetch(`${PUBLIC_API_URL}/admin/me`, { credentials: 'include' }),
            ]);
            auth = authResp.ok ? await authResp.json() : { authenticated: false };
            adminState = adminResp.ok ? await adminResp.json() : null;
        } catch (_) {
            auth = { authenticated: false };
            adminState = null;
        } finally {
            authLoaded = true;
        }
    }

    onMount(() => {
        refreshAuth();
    });

    // Expose refreshAuth on the window so the claim-profile page can trigger
    // a refresh after a successful claim, without a full page reload.
    $effect(() => {
        if (typeof window !== 'undefined') {
            (window as any).__refreshAuth = refreshAuth;
        }
    });

    const navItems = [
        { href: '/', label: 'Call to Arms' },
        { href: '/pairings', label: 'Pairings' },
        { href: '/league', label: 'Old World League' },
        { href: '/players', label: 'Players' }
    ];

    function isActive(href: string): boolean {
        if (href === '/') return page.url.pathname === '/';
        return page.url.pathname.startsWith(href);
    }

    const isAuthed = $derived(auth.authenticated === true);
    const needsClaim = $derived(isAuthed && auth.user?.player_id == null);
    const hasAdminAccess = $derived(
        authLoaded && adminState !== null && (adminState.is_super_admin || adminState.scopes.length > 0)
    );

    function loginUrl(): string {
        return `${PUBLIC_API_URL}/auth/discord/login`;
    }

    async function logout() {
        await fetch(`${PUBLIC_API_URL}/auth/logout`, {
            method: 'POST',
            credentials: 'include'
        });
        await refreshAuth();
        window.location.href = '/';
    }

    function closeDrawer() {
        drawerOpen = false;
    }

    function toggleDrawer() {
        drawerOpen = !drawerOpen;
    }
</script>

<svelte:head>
    <title>Call to Arms</title>
</svelte:head>

{#if $navigating}
    <div class="nav-progress"></div>
{/if}

<!-- Mobile-only top bar with hamburger toggle -->
<div class="mobile-topbar">
    <button class="hamburger" onclick={toggleDrawer} type="button" aria-label="Open menu">
        {#if drawerOpen}
            <span class="hamburger-icon">✕</span>
        {:else}
            <span class="hamburger-icon">☰</span>
        {/if}
    </button>
</div>

<!-- Mobile-only dimmed overlay, shown when the drawer is open -->
{#if drawerOpen}
    <div class="drawer-overlay" onclick={closeDrawer}></div>
{/if}

<div class="page-wrap" data-sveltekit-preload-data="hover">
    <aside class="sidebar" class:drawer-open={drawerOpen}>
        <div class="sidebar-block">
            {#if !authLoaded}
                <h2 class="sidebar-heading">Access</h2>
                <p class="sidebar-note">…</p>
            {:else if isAuthed && auth.user}
                <h2 class="sidebar-heading">Access</h2>
                {#if auth.player}
                    <a class="user-pill user-pill-link" href={`/players/${auth.player.id}`} onclick={closeDrawer}>
                        {#if auth.user.avatar_url}
                            <img class="user-avatar" src={auth.user.avatar_url} alt="" />
                        {/if}
                        <div class="user-meta">
                            <div class="user-name">{auth.user.discord_name}</div>
                            <div class="user-sub">{auth.player.name}</div>
                        </div>
                    </a>
                {:else}
                    <div class="user-pill">
                        {#if auth.user.avatar_url}
                            <img class="user-avatar" src={auth.user.avatar_url} alt="" />
                        {/if}
                        <div class="user-meta">
                            <div class="user-name">{auth.user.discord_name}</div>
                            <div class="user-sub user-sub-warn">No profile linked</div>
                        </div>
                    </div>
                {/if}
                <button class="sidebar-button" onclick={() => { closeDrawer(); logout(); }} type="button">Sign out</button>
            {:else}
                <h2 class="sidebar-heading">Access</h2>
                <p class="sidebar-note">Sign in to submit results and sign up for sessions.</p>
                <a class="sidebar-button sidebar-button-primary" href={loginUrl()} onclick={closeDrawer}>
                    Sign in with Discord
                </a>
            {/if}
        </div>

        <div class="sidebar-divider"></div>

        <div class="brand-stack">
            <a class="sidebar-link" href="https://elementgames.co.uk" target="_blank" rel="noopener">
                <img src="/brand/element_games.png" alt="Element Games" />
            </a>

            <a class="sidebar-link" href="https://discord.gg/tnwUCRYH" target="_blank" rel="noopener">
                <img src="/brand/discord.png" alt="Discord" />
            </a>
        </div>
    </aside>

    <main class="container">
        <nav class="nav-tabs-wrap">
            <div class="nav-tabs">
                {#each navItems as item}
                    <a href={item.href} class="nav-tab" class:active={isActive(item.href)} data-sveltekit-preload-data="hover">{item.label}</a>
                {/each}
                {#if hasAdminAccess}
                    <a href="/admin" class="nav-tab" class:active={isActive('/admin')} data-sveltekit-preload-data="hover">Admin</a>
                {/if}
            </div>
            <div class="nav-tabs-fade"></div>
        </nav>

        <div class="page-content">
            {#if !authLoaded}
                <div class="auth-gate"></div>
            {:else if !isAuthed && !page.url.pathname.startsWith('/pairings')}
                <div class="auth-gate">
                    <h1 class="auth-gate-title">Call to Arms</h1>
                    <p class="auth-gate-text">
                        Sign in with Discord to view league standings and player profiles.
                    </p>
                    <a class="auth-gate-button" href={loginUrl()}>Sign in with Discord</a>
                </div>
            {:else}
                {#if needsClaim && page.url.pathname !== '/claim' && auth.user}
                    <div class="claim-banner">
                        <strong>Welcome, {auth.user.discord_name}.</strong>
                        Before you can use the app, please
                        <a href="/claim">link your existing player profile</a>.
                    </div>
                {/if}
                {#key page.url.pathname}
                    <div class="page-transition" in:fly={{ y: 10, duration: 220 }}>
                        {@render children()}
                    </div>
                {/key}
            {/if}
        </div>
    </main>
</div>

<style>
    .nav-progress {
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        height: 3px;
        background: linear-gradient(90deg, transparent, var(--color-accent), transparent);
        background-size: 50% 100%;
        background-repeat: no-repeat;
        z-index: 1000;
        animation: nav-progress-slide 0.9s ease-in-out infinite;
        pointer-events: none;
    }

    @keyframes nav-progress-slide {
        0%   { background-position: -50% 0; }
        100% { background-position: 150% 0; }
    }

    /* Mobile-only top bar; hidden entirely on desktop */
    .mobile-topbar {
        display: none;
    }

    .hamburger {
        background: rgba(0, 0, 0, 0.25);
        border: 1px solid var(--color-accent-border-soft);
        color: var(--color-text-bright);
        width: 40px;
        height: 40px;
        border-radius: 8px;
        font-size: 1.2rem;
        line-height: 1;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
    }

    .hamburger-icon {
        display: block;
    }

    /* Dimmed backdrop behind the open drawer; mobile-only */
    .drawer-overlay {
        display: none;
    }

    .page-wrap {
        display: flex;
        min-height: 100vh;
        gap: 1rem;
        padding: 1rem;
    }

    .sidebar {
        flex: 0 0 200px;
        display: flex;
        flex-direction: column;
        gap: 0.5rem;
        padding-top: 0.25rem;
    }

    .sidebar-heading {
        font-size: 1.1rem;
        font-weight: 700;
        color: var(--color-text-base);
        margin: 0 0 0.5rem;
    }

    .sidebar-note {
        font-size: 0.78rem;
        color: var(--color-text-dim);
        margin: 0 0 0.5rem;
        line-height: 1.4;
    }

    .sidebar-block { padding: 0.25rem 0.25rem 0.5rem; }

    .sidebar-divider {
        height: 1px;
        background: var(--color-accent-border-soft);
        margin: 0.25rem 0;
    }

    .sidebar-button {
        display: block;
        width: 100%;
        background: rgba(0, 0, 0, 0.25);
        border: 1px solid var(--color-accent-border-soft);
        color: var(--color-text-base);
        padding: 0.5rem 0.6rem;
        border-radius: 8px;
        font-size: 0.82rem;
        font-family: inherit;
        text-align: center;
        text-decoration: none;
        cursor: pointer;
        transition: background 0.1s ease, border-color 0.1s ease;
    }

    .sidebar-button:hover {
        background: rgba(201, 161, 74, 0.10);
        border-color: rgba(201, 161, 74, 0.55);
    }

    .sidebar-button-primary {
        background: rgba(201, 161, 74, 0.18);
        border-color: rgba(201, 161, 74, 0.55);
        color: var(--color-text-bright);
        font-weight: 600;
    }

    .user-pill {
        display: flex;
        align-items: center;
        gap: 0.5rem;
        margin-bottom: 0.5rem;
    }

    .user-avatar {
        width: 36px;
        height: 36px;
        border-radius: 50%;
        object-fit: cover;
        border: 1px solid var(--color-accent-border-soft);
        flex: 0 0 auto;
    }

    .user-pill-link {
        text-decoration: none;
        color: inherit;
        cursor: pointer;
        border-radius: 8px;
        transition: background 0.1s ease;
    }

    .user-pill-link:hover {
        background: rgba(201, 161, 74, 0.08);
    }

    .user-meta { flex: 1; min-width: 0; }

    .user-name {
        font-size: 0.88rem;
        font-weight: 600;
        color: var(--color-text-bright);
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }

    .user-sub {
        font-size: 0.72rem;
        color: var(--color-text-dim);
        font-style: italic;
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
    }

    .user-sub-warn { color: var(--color-tnt); font-style: normal; }

    .sidebar-link {
        display: flex;
        align-items: center;
        justify-content: center;
        text-decoration: none;
        padding: 0.3rem 0;
    }

    .brand-stack {
        display: flex;
        flex-direction: column;
        align-items: center;
        gap: 0.4rem;
    }

    .sidebar-link img {
        max-width: 140px;
        max-height: 45px;
        height: auto;
        object-fit: contain;
    }

.container {
        flex: 1;
        min-width: 0;
        padding: 1.8rem 2rem 1.5rem;
        background: var(--color-bg-deep);
    }

    /* Wrapper around the scrollable tab row, needed for the fade overlay */
    .nav-tabs-wrap {
        position: relative;
        margin-bottom: 1.5rem;
    }

    .nav-tabs {
        display: flex;
        gap: 1.5rem;
        border-bottom: 1px solid var(--color-accent-border);
        padding-bottom: 0.6rem;
        position: relative;
    }

    .nav-tab {
        color: var(--color-text-base);
        text-decoration: none;
        font-size: 0.95rem;
        padding-bottom: 0.4rem;
        margin-bottom: -0.7rem;
        border-bottom: 3px solid transparent;
        transition: color 0.2s ease, border-bottom-color 0.25s ease;
        position: relative;
    }

    .nav-tab:hover { color: var(--color-text-bright); }

    .nav-tab.active {
        color: var(--color-accent);
        border-bottom-color: var(--color-accent-soft);
    }

    .nav-tab.active::after {
        content: '';
        position: absolute;
        left: 0;
        right: 0;
        bottom: -0.7rem;
        height: 3px;
        background: var(--color-accent-soft);
        border-radius: 2px;
        animation: tab-underline-pop 0.35s ease;
    }

    @keyframes tab-underline-pop {
        0%   { transform: scaleX(0.2); opacity: 0; }
        100% { transform: scaleX(1);   opacity: 1; }
    }

    /* Right-edge fade hinting the tab row scrolls; invisible unless overflowing */
    .nav-tabs-fade {
        display: none;
    }

    .page-content { padding-top: 0.5rem; }

    .claim-banner {
        background: rgba(217, 122, 42, 0.10);
        border: 1px solid rgba(217, 122, 42, 0.45);
        color: var(--color-text-bright);
        padding: 0.75rem 1rem;
        border-radius: 10px;
        margin-bottom: 1rem;
        font-size: 0.9rem;
    }

    .claim-banner a {
        color: var(--color-accent);
        text-decoration: underline;
        font-weight: 600;
    }

    .auth-gate {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        text-align: center;
        min-height: 50vh;
        gap: 1rem;
        padding: 2rem 1rem;
    }

    .auth-gate-title {
        font-size: 1.6rem;
        font-weight: 700;
        color: var(--color-text-bright);
        margin: 0;
    }

    .auth-gate-text {
        font-size: 0.92rem;
        color: var(--color-text-dim);
        max-width: 360px;
        line-height: 1.5;
        margin: 0;
    }

    .auth-gate-button {
        display: inline-block;
        background: rgba(201, 161, 74, 0.18);
        border: 1px solid rgba(201, 161, 74, 0.55);
        color: var(--color-text-bright);
        font-weight: 600;
        padding: 0.65rem 1.6rem;
        border-radius: 8px;
        font-size: 0.95rem;
        text-decoration: none;
        font-family: inherit;
        cursor: pointer;
        transition: background 0.1s ease, border-color 0.1s ease;
    }

    .auth-gate-button:hover {
        background: rgba(201, 161, 74, 0.28);
    }

    @media (max-width: 768px) {
        /* Show the hamburger bar on mobile */
        .mobile-topbar {
            display: block;
            position: fixed;
            top: 0.6rem;
            left: 0.6rem;
            z-index: 960;
        }

        .page-wrap {
            padding: 0.5rem;
        }

        /* Dim the page behind the open drawer */
        .drawer-overlay {
            display: block;
            position: fixed;
            inset: 0;
            background: rgba(0, 0, 0, 0.55);
            z-index: 900;
        }

        .page-wrap {
            flex-direction: column;
            padding: 0.5rem;
            padding-top: 0;
        }

        /* The sidebar becomes a left slide-out drawer, hidden by default */
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            bottom: 0;
            z-index: 950;
            width: 78vw;
            max-width: 300px;
            background: var(--color-sidebar-bg);
            border-right: 1px solid var(--color-accent-border);
            padding: 1rem;
            overflow-y: auto;
            transform: translateX(-100%);
            transition: transform 0.25s ease;
            flex: none;
            display: flex;
            flex-direction: column;
        }

        .sidebar .sidebar-divider {
            margin-top: auto;
        }

        .sidebar.drawer-open {
            transform: translateX(0);
        }

        .sidebar-block { padding-top: 2.75rem; }
        .sidebar-divider { margin: 0.75rem 0; }

        .brand-stack {
            flex-direction: column;
            align-items: center;
            gap: 1rem;
            width: 100%;
        }
        .sidebar-link {
            justify-content: center;
            width: 100%;
        }
        .sidebar-link img {
            max-height: 60px;
            width: 100%;
            object-fit: contain;
        }

        .sidebar-button { font-size: 0.85rem; padding: 0.6rem; }

        .container { padding: 1rem; }

        .nav-tabs {
            gap: 0.8rem;
            font-size: 0.85rem;
            overflow-x: auto;
            white-space: nowrap;
            -webkit-overflow-scrolling: touch;
            padding-left: 3rem;
        }

        /* Right-edge fade so a partially-hidden "Admin" tab reads as
           scrollable rather than clipped */
        .nav-tabs-fade {
            display: block;
            position: absolute;
            top: 0;
            right: 0;
            bottom: 0.6rem;
            width: 28px;
            background: linear-gradient(to right, transparent, var(--color-bg-base));
            pointer-events: none;
        }
    }
</style>